# encoding: UTF-8
# frozen_string_literal: true

# Specs in this file have access to a helper object that includes
# the Private::AssetsHelper. For example:
#
# describe Private::AssetsHelper do
#   describe "string concat" do
#     it "concats two strings with spaces" do
#       expect(helper.concat_strings("this","that")).to eq("this that")
#     end
#   end
# end
describe Private::AssetsHelper do
  pending "add some examples to (or delete) #{__FILE__}"
end
