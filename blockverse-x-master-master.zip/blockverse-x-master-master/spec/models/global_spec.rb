# encoding: UTF-8
# frozen_string_literal: true

describe Global do
  let(:global) { Global[:btcusd] }
end
