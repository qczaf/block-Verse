# encoding: UTF-8
# frozen_string_literal: true

describe PartialTree do
  pending "add some examples to (or delete) #{__FILE__}"
end
