# encoding: UTF-8
# frozen_string_literal: true

describe Private::FundsController, type: :controller do

end
