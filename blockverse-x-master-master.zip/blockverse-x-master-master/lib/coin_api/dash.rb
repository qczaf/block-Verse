# encoding: UTF-8
# frozen_string_literal: true

module CoinAPI
  class DASH < BTC

  end
end
