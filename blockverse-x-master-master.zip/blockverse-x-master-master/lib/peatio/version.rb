# encoding: UTF-8
# frozen_string_literal: true

module Peatio
  VERSION = '1.8.38'
end
