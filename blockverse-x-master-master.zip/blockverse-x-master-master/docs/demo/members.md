# Generating demo members

To feed database with demo members (including admin account) execute the following:

`bundle exec rake peatio:feed`

Member access level & email will be printed on the screen.
