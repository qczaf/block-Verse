# Getting ERC20 tokens in Rinkeby Testnet

When system will generate your personal ERC20 deposit address you may want to deposit some coins to it. Peatio recommends Rinkeby Ethereum Testnet.

To get test tokens in Rinkeby network:

1) to get a TRST (WeTrust) coins in the Testnet, follow the instructions [here](https://github.com/WeTrustPlatform/erc20faucet-contracts).

2) to get a HUR (Hurify) coins in the Testnet, follow the instructions [here](https://medium.com/@Hurify/metamask-installation-and-adding-hur-tokens-on-test-network-for-platform-evaluation-bb7438bf54cd).

