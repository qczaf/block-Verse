class CustomController < ApplicationController
    def home

    end

    def about
    
    end


end    
